
function [W, B] = computeSB_SNPDE_Hv2(fea, gnd)

W = computeS_SNPDEv2(fea, gnd);
nSmp = size(fea,2);

B = zeros(size(W));
d = zeros(nSmp,1);

for i = 1 : nSmp
    Wi = W(i,:);
    Wi(Wi<=0)=inf;    
    [Dump,indi] = min(Wi);
    d(i) = norm(fea(:,i)-fea(:,indi));    
    for j = 1 : nSmp
        if gnd(i)~=gnd(j)
            dij = norm(fea(:,i)-fea(:,j));
            if dij < d(i)
                B(i,j) = exp(-dij^2);
            end
        end
    end    
end