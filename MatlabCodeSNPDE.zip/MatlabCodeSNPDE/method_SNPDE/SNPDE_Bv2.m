function [eigVecs, eigVals] = SNPDE_Bv2(train_sample,train_label, max_dim)

%%
% SNPDE-B: Sparse Neighborhood Preserving Discriminant Embedding
%
%   [eigVecs, eigVals] = SNPDE_Bv2(train_sample,train_label, max_dim);
%   Input:
%      train_sample - Data matrix. Each column vector of fea is a data point.
%      train_label  - Data label vector.
%      max_dim      - maximum number of dimensionality of subspace
%
%   Output:
%      eigVecs    - Each column is an embedding, for a new
%                   data point (colume vector) x, 
%                   y = eig_vec'* x will be the embedding
%                   result of x.
%      eigVals    - The sorted eigvalue of eig_vec. 
% 
%
%    Examples:
%
%       fea = rand(100,50);
%       gnd = [ones(1,10) 2*ones(1,10) 3*ones(1,10) 4*ones(1,10) 5*ones(1,10)];
%       gama = 0.1;
%       max_dim = 200;
%       [eigVecs, eigVals] = SNPDE_Bv2(train_sample,train_label, max_dim);
%       Y = eigVecs'*fea;       
%
%
%   Mar. 2017 
%   Dec. 2017 update
%
%   Written by Jianbo Zhang (zjb510@126.com  zhangjianbo@neuq.edu.cn)
%
%%

[S, B] = computeSB_SNPDE_Bv2(train_sample, train_label);

S = S + S' - S'*S;
S = eye(size(S)) - S;
S_W = train_sample*S*train_sample';
clear S;

D2 = diag(sum(B,2)+sum(B,1)');
B = (B + B')/2;
Lb =  D2 - B;
clear D2 B;
S_B = train_sample*Lb*train_sample';
clear Lb;

[eigVecs, eigVals] = eig(S_B, S_W);
clear S_B S_W;

eigVals = diag(eigVals);
[eigVals, index] = sort(eigVals, 'descend'); 
eigVecs = eigVecs(:, index);
eigVecs = eigVecs(:, 1:min(size(eigVecs,2), max_dim));
