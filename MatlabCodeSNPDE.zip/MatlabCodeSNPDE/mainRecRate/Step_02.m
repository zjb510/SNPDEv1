 % Step 1: repeat _timenum_ time test
for j = 1 : timenum
    if DEBUG == 1
        disp(j);
    end
    
    %-------- 1��Construct train set and test set ------
    filename = strcat(pwd, '\DATA\n-trains\', databasename, '\', ...
        num2str(train_samplesize), '-train\', num2str(j), '.mat');
    load (filename);
    fea_train = fea(gnd_train,:);
    gnd_train = gnd(gnd_train);
    fea_test = fea(gnd_test,:);
    gnd_test = gnd(gnd_test);
    
    %-------- 2��PCA ------
    %    [Pro_Matrix, pca_ratio] = my_pca(fea_train', pca_ratio, tol_train - ClassNum);
    options = [];
    options.PCARatio = pca_ratio;
    Pro_Matrix = PCA(fea_train, options);
    fea_train_pca = fea_train*Pro_Matrix;
    fea_test_pca = fea_test*Pro_Matrix;
    fea_train_pca = normc(fea_train_pca')';
    fea_test_pca = normc(fea_test_pca')';            
    
    %------ 3��compute and total ------
    if SPP > 0
        mthd = SPP;
        disp(['STARTing of ' methodname{mthd} ' with ' num2str(train_samplesize) '-trains ...']);
        eig_vec = SPP1v1(fea_train_pca',gnd_train', max(pro_dim));
        if DEBUG == 0
            mindim = min(dimnum,size(eig_vec,2));
            for i = mindim : -1 : 1
                fea_train_new = fea_train_pca*eig_vec(:,1:pro_dim(i));
                fea_test_new = fea_test_pca*eig_vec(:,1:pro_dim(i));
                a = KNN(fea_train_new, gnd_train, fea_test_new, gnd_test, 'Cos');
                if i == mindim || mod(i,10)==0
                    fprintf('%s: \t\trepeattime(%02.0f), \tdim(%03.0f), \trate(%2.10f%%)\n', methodname{mthd}, j, i, a*100);
                end
                accuracy(i, j+1, mthd) = a;
            end
            accuracy((mindim+1):dimnum, j+1, mthd) = accuracy(mindim, j+1, mthd);
        end
        disp(['END of ' methodname{mthd} '.']);
    end
    
    if DSNPE > 0
        mthd = DSNPE;
        disp(['STARTing of ' methodname{mthd} ' with ' num2str(train_samplesize) '-trains ...']);
        eig_vec = DSNPE1v1(fea_train_pca',gnd_train', max(pro_dim), 1);
        if DEBUG == 0
            mindim = min(dimnum,size(eig_vec,2));
            for i = mindim : -1 : 1
                fea_train_new = fea_train_pca*eig_vec(:,1:pro_dim(i));
                fea_test_new = fea_test_pca*eig_vec(:,1:pro_dim(i));
                a = KNN(fea_train_new, gnd_train, fea_test_new, gnd_test, 'L2');
                if i == mindim || mod(i,10)==0
                    fprintf('%s: \t\trepeattime(%02.0f), \tdim(%03.0f), \trate(%2.10f%%)\n', methodname{mthd}, j, i, a*100);
                end
                accuracy(i, j+1, mthd) = a;
            end
            accuracy((mindim+1):dimnum, j+1, mthd) = accuracy(mindim, j+1, mthd);
        end
        disp(['END of ' methodname{mthd} '.']);
    end
    
    if DSPP_B > 0
        mthd = DSPP_B;
        disp(['STARTing of ' methodname{mthd} ' with ' num2str(train_samplesize) '-trains ...']);
        eig_vec = DSPP_Bv1(fea_train_pca',gnd_train', max(pro_dim), 0.0002);
        if DEBUG == 0
            mindim = min(dimnum,size(eig_vec,2));
            for i = mindim : -1 : 1
                fea_train_new = fea_train_pca*eig_vec(:,1:pro_dim(i));
                fea_test_new = fea_test_pca*eig_vec(:,1:pro_dim(i));
                a = KNN(fea_train_new, gnd_train, fea_test_new, gnd_test, 'Cos');
                if i == mindim || mod(i,10)==0
                    fprintf('%s: \trepeattime(%02.0f), \tdim(%03.0f), \trate(%2.10f%%)\n', methodname{mthd}, j, i, a*100);
                end
                accuracy(i, j+1, mthd) = a;
            end
            accuracy((mindim+1):dimnum, j+1, mthd) = accuracy(mindim, j+1, mthd);
        end
        disp(['END of ' methodname{mthd} '.']);
    end
    
    if DSPP_H > 0
        mthd = DSPP_H;
        disp(['STARTing of ' methodname{mthd} ' with ' num2str(train_samplesize) '-trains ...']);
        eig_vec = DSPP_Hv1(fea_train_pca',gnd_train', max(pro_dim), 0.0002);
        if DEBUG == 0
            mindim = min(dimnum,size(eig_vec,2));
            for i = mindim : -1 : 1
                fea_train_new = fea_train_pca*eig_vec(:,1:pro_dim(i));
                fea_test_new = fea_test_pca*eig_vec(:,1:pro_dim(i));
                a = KNN(fea_train_new, gnd_train, fea_test_new, gnd_test, 'Cos');
                if i == mindim || mod(i,10)==0
                    fprintf('%s: \trepeattime(%02.0f), \tdim(%03.0f), \trate(%2.10f%%)\n', methodname{mthd}, j, i, a*100);
                end
                accuracy(i, j+1, mthd) = a;
            end
            accuracy((mindim+1):dimnum, j+1, mthd) = accuracy(mindim, j+1, mthd);
        end
        disp(['END of ' methodname{mthd} '.']);
    end
    
    if GRSDA > 0
        disp(['STARTing of GRSDA with ' num2str(train_samplesize) '-trains ...']);
        eig_vec = GRSDAv1(fea_train_pca',gnd_train', max(pro_dim));%
        if DEBUG == 0
            mindim = min(dimnum,size(eig_vec,2));
            for i = mindim : -1 : 1
                fea_train_new = fea_train_pca*eig_vec(:,1:pro_dim(i));
                fea_test_new = fea_test_pca*eig_vec(:,1:pro_dim(i));
                a = KNN(fea_train_new, gnd_train, fea_test_new, gnd_test, 'Cos');
                if i == mindim || mod(i,10)==0
                    fprintf('GRSDA: \t\trepeattime(%02.0f), \tdim(%03.0f), \trate(%2.10f%%)\n', j, i, a*100);
                end
                accuracy(i, j+1, GRSDA) = a;
            end
            accuracy((mindim+1):dimnum, j+1, GRSDA) = accuracy(mindim, j+1, GRSDA);
        end
        disp('END of GRSDA.');
    end
    
    if SMMSD > 0
        mthd = SMMSD;
        disp(['STARTing of ' methodname{mthd} ' with ' num2str(train_samplesize) '-trains ...']);
        eig_vec = SMMSDv1(fea_train_pca',gnd_train', max(pro_dim));%
        if DEBUG == 0
            mindim = min(dimnum,size(eig_vec,2));
            for i = mindim : -1 : 1
                fea_train_new = fea_train_pca*eig_vec(:,1:pro_dim(i));
                fea_test_new = fea_test_pca*eig_vec(:,1:pro_dim(i));
                a = KNN(fea_train_new, gnd_train, fea_test_new, gnd_test, 'L2');
                if i == mindim || mod(i,10)==0
                    fprintf('%s: \t\trepeattime(%02.0f), \tdim(%03.0f), \trate(%2.10f%%)\n', methodname{mthd}, j, i, a*100);
                end
                accuracy(i, j+1, mthd) = a;
            end
            accuracy((mindim+1):dimnum, j+1, mthd) = accuracy(mindim, j+1, mthd);
        end
        disp(['END of ' methodname{mthd} '.']);
    end

    if SNPDE_B > 0
        mthd = SNPDE_B;
        disp(['STARTing of ' methodname{mthd} ' with ' num2str(train_samplesize) '-trains ...']);
        eig_vec = SNPDE_Bv2(fea_train_pca',gnd_train', max(pro_dim));
        if DEBUG == 0
            mindim = min(dimnum,size(eig_vec,2));
            for i = mindim : -1 : 1
                fea_train_new = fea_train_pca*eig_vec(:,1:pro_dim(i));
                fea_test_new = fea_test_pca*eig_vec(:,1:pro_dim(i));
                a = KNN(fea_train_new, gnd_train, fea_test_new, gnd_test, 'L2');
                if i == mindim || mod(i,10)==0
                    fprintf('%s: \trepeattime(%02.0f), \tdim(%03.0f), \trate(%2.10f%%)\n', methodname{mthd}, j, i, a*100);
                end
                accuracy(i, j+1, mthd) = a;
            end
            accuracy((mindim+1):dimnum, j+1, mthd) = accuracy(mindim, j+1, mthd);
        end
        disp(['END of ' methodname{mthd} '.']);
    end
    
    if SNPDE_H > 0
        mthd = SNPDE_H;
        disp(['STARTing of ' methodname{mthd} ' with ' num2str(train_samplesize) '-trains ...']);
        eig_vec = SNPDE_Hv2(fea_train_pca',gnd_train', max(pro_dim));
        if DEBUG == 0
            mindim = min(dimnum,size(eig_vec,2));
            for i = mindim : -1 : 1
                fea_train_new = fea_train_pca*eig_vec(:,1:pro_dim(i));
                fea_test_new = fea_test_pca*eig_vec(:,1:pro_dim(i));
                a = KNN(fea_train_new, gnd_train, fea_test_new, gnd_test, 'L2');
                if i == mindim || mod(i,10)==0
                    fprintf('%s: \trepeattime(%02.0f), \tdim(%03.0f), \trate(%2.10f%%)\n', methodname{mthd}, j, i, a*100);
                end
                accuracy(i, j+1, mthd) = a;
            end
            accuracy((mindim+1):dimnum, j+1, mthd) = accuracy(mindim, j+1, mthd);
        end
        disp(['END of ' methodname{mthd} '.']);
    end
end