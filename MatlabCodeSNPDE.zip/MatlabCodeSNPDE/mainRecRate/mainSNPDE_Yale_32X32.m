clear
%clc
%close all
addpath(genpath(pwd));

ts      = 4:1:7;     % number of training samples

%%%%%%%%%%%%%%%%% import data %%%%%%%%%%%%%%%%%%%%%
databasename = 'Yale';
load Yale_15c_11s_32X32.mat;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Step_01;