
SPP     = 0;
DSNPE   = 0;
DSPP_B  = 0;
DSPP_H  = 0;
GRSDA   = 0;
SMMSD   = 6;
%RCDA    = 7;
SNPDE_B = 0;
SNPDE_H = 0;

DEBUG   = 0;

pro_dim = 1:1:200;

timenum = 20;           % repeat times
pca_ratio = 0.98;

%%%%%%%%%%%%%% rescaling to [0, 1] %%%%%%%%%%%%%%
fea = im2double(fea);
n = length(gnd);
for i = 1 : n
    temp = 255;
    fea(i, :) = fea(i,:)/temp;
end
clear temp;

ClassNum = length(unique(gnd));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for train_samplesize = ts
    
    %%%%%%%%%%%%%%%%% Begin: basic parameter %%%%%%%%%%%%%%%%%%%
    tol_train = train_samplesize*ClassNum;
    tol_test = length(gnd) - tol_train;

    dimnum = length(pro_dim);

%     methodname = {    'SPP'       'DSNPE'     'DSPP-B'    'DSPP-H' ...
%                       'GRSDA'     'SMMSD'     'RCDA'      'SNPDE-B'   'SNPDE-H'};
%     methodlinestyle = {
%         'LineStyle',  '-',        '--',       '-.',       '--',    ...
%                       '-.',       '-',        '-.',       '--',       '-.';
%         'Color',      [.6 .2 .6], [.2 .3 .6], [.2 .5 .2], [.9 .0 .9], ...
%                       [.6 .3 .1], [.6 .5 .1], [.7 .1 .3], [.0 .0 .9], [.9 .2 .2];
%         'Marker',     '^',        '*',        '<',        '>', ...
%                       'd',        'o',        '+',        's',        'h';
%     };
    methodname = {    'SPP'       'DSNPE'     'DSPP-B'    'DSPP-H' ...
                      'GRSDA'     'SMMSD'     'SNPDE-B'   'SNPDE-H'};
    methodlinestyle = {
        'LineStyle',  '-',        '--',       '-.',       '--',    ...
                      '-.',       '-',        '--',       '-.';
        'Color',      [.6 .2 .6], [.2 .3 .6], [.2 .5 .2], [.9 .0 .9], ...
                      [.6 .3 .1], [.6 .5 .1], [.0 .0 .9], [.9 .2 .2];
        'Marker',     '^',        '*',        '<',        '>', ...
                      'd',        '+',        's',        'h';
    };
    methodnum = length(methodname);
    %%%%%%%%%%%%%%%%%% END: basic parameter %%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%% alloc memory for saving result  %%%%%%%%%%%%%%%
    accuracy = zeros(dimnum, 1+timenum, methodnum);
    for k = 1 : methodnum
        accuracy(:,1,k) = pro_dim';
    end

    mean_process_accuracy = zeros(dimnum, 3, methodnum);
    for k = 1 : methodnum
        mean_process_accuracy(:,1,k) = pro_dim';
    end
    %%%%%%%%%%%%% END: alloc memory for saving result %%%%%%%%%%%%%%

    %%%%%%%%%% BEGIN: Test  %%%%%%%%%%%%%%%%%%%%%%%%%%
    methodnames = '';

   
    if SPP     > 0 methodnames = [methodnames '-SPP'];         end
    if DSNPE   > 0 methodnames = [methodnames '-DSNPE'];       end
    if DSPP_B  > 0 methodnames = [methodnames '-DSPP_B'];      end
    if DSPP_H  > 0 methodnames = [methodnames '-DSPP_H'];      end
    if GRSDA   > 0 methodnames = [methodnames '-GRSDA'];       end
    if SMMSD   > 0 methodnames = [methodnames '-SMMSD'];       end
    %if RCDA    > 0 methodnames = [methodnames '-RCDA'];        end
    if SNPDE_B > 0 methodnames = [methodnames '-SNPDE_B'];     end    
    if SNPDE_H > 0 methodnames = [methodnames '-SNPDE_H'];     end

    fprintf(['\ndatabase��' databasename ...
        '\n   number  of  training��' num2str(train_samplesize) '(' num2str(ts(1)) ', ' num2str(ts(end)) ')' ...
        '\n   dimensionality range��[d' num2str(pro_dim(1)) ', d' num2str(pro_dim(end)) ']' ...
        '\n   methods name��' methodnames ...
        '\n   repeat times number ��' num2str(timenum) '\n']);
    
    Step_02;
    Step_Others;
end