clear
%clc
%close all
addpath(genpath(pwd));

ts      = 7:1:10;     % number of training samples

%%%%%%%%%%%%%%%%% import data %%%%%%%%%%%%%%%%%%%%%
databasename = 'PIE';
load PIE_68c_24s_32X32.mat;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Step_01;