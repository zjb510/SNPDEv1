clear
%clc
%close all
addpath(genpath(pwd));

ts      = 5:1:8;     % number of training samples

%%%%%%%%%%%%%%%%% import data %%%%%%%%%%%%%%%%%%%%%
databasename = 'AR14s';
load AR_100c_14s_44X32.mat;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Step_01;