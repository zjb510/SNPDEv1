clear
%clc
%close all
addpath(genpath(pwd));

ts      = 8:1:11;     % number of training samples

%%%%%%%%%%%%%%%%% import data %%%%%%%%%%%%%%%%%%%%%
databasename = 'EYB';
load EYB_31c_64s_32X32.mat;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Step_01;