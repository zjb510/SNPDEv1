% Step 2 : save result
filename = [pwd '\result\v02_' databasename ...
    '(' num2str(train_samplesize) ')' ...
    '[d' num2str(pro_dim(1)) '-d' num2str(pro_dim(end)) ']' ...
    '(r' num2str(timenum) ')' methodnames];
save(filename, 'accuracy', 'train_samplesize', 'databasename'); 

% Step 3: total result
for k = 1 : methodnum
    rr = accuracy(:,2:timenum+1,k);
    mean_process_accuracy(:,2:3,k) = [mean(rr,2) std(rr',1)'];
end

% Step 4: plot the result
K = [1 2 3 4 5 6 7 8];  % switch to corresponding method
figure('Position',[200 200 500 350], 'name', databasename);
hold on;grid on;box on;
for k = K%1 : methodnum    
    plot(mean_process_accuracy(1:5:200, 1, k), mean_process_accuracy(1:5:200, 2, k)*100, ...
        methodlinestyle{1, 1}, methodlinestyle{1, k+1}, ...
        methodlinestyle{2, 1}, methodlinestyle{2, k+1}, ...
        methodlinestyle{3, 1}, methodlinestyle{3, k+1}, ...
        'LineWidth', 1.3);
end
legend(methodname{K}, 'Location','SouthEast');
xlabel('Number of Project Vectors');
ylabel('Recognition Accuracy(%)');
set(gca,'XTick',0:20:200);
set(gca,'YTick',0:10:100);
xlim([0,200]);
ylim([0,100]);
if strcmp(databasename, 'EYB')
	ylim([0,90]);
end
title([num2str(train_samplesize) '-train']);

% Step 5�� display result
biaoge = cell(length(K)+1,4);
biaoge{1,1} = 'Methods';
biaoge{1,2} = 'RR(%)';
biaoge{1,3} = 'Std';
biaoge{1,4} = 'Dim';
for k = 1:length(K)
    biaoge{k+1,1} = methodname{K(k)};
    [MA, ind] = max(mean_process_accuracy(:, 2, K(k)));
    biaoge{k+1,2} = num2str(round(MA*100, 2));
    biaoge{k+1,3} = num2str(round(mean_process_accuracy(ind, 3, K(k)), 3));
    biaoge{k+1,4} = num2str(ind);
end
disp(biaoge);