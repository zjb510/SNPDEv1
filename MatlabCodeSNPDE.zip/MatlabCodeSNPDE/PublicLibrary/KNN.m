function rate = KNN(Train_data, Train_label, Test_data, Test_label, Distance_mark)
% K-Nearest-Neighbor classifier(K-NN classifier)
%Input:
%     Train_data,Test_data are training data set and test data
%     set,respectively.(Each row is a data point)
%     Train_label,Test_label are column vectors.They are labels of training
%     data set and test data set,respectively.
%     k is the number of nearest neighbors
%     Distance_mark           :   ['Euclidean', 'L2'| 'L1' | 'Cos'] 
%     'Cos' represents Cosine distance.
%Output:
%     rate:Accuracy of K-NN classifier
%This code is written by Gui Jie in the evening 2009/03/11.
%If you have find some bugs in the codes, feel free to contract me


if nargin < 4
    error('Not enought arguments!');
elseif nargin < 5
    Distance_mark = 'L2';
end

test_num   = size(Test_data, 1);% number of test data set
train_num  = size(Train_data, 1); % number of training data set

% Normalize each feature to have zero mean and unit variance.
% If you need the following four rows,you can uncomment them.
% M        = mean(Train_data); % mean & std of the training data set
% S        = std(Train_data);
% Train_data = (Train_data - ones(train_num, 1) * M)./(ones(train_num, 1) * S); % normalize training data set
% Test_data            = (Test_data-ones(n,1)*M)./(ones(n,1)*S); % normalize data

U        = unique(Train_label); % class labels
% nclasses = length(U);%number of classes

Result  = zeros(test_num, 1);
dist = zeros(train_num,1);
for i = 1 : test_num
    % compute distances between test data and all training data and
    % sort them
    for j = 1 : train_num
        V = Test_data(i,:) - Train_data(j,:);
        switch Distance_mark
            case {'Euclidean', 'L2'}
                dist(j,1)=norm(V,2); % Euclead (L2) distance
            case 'L1'
                dist(j,1)=norm(V,1); % L1 distance
            case 'Cos'
                %dist(j,1)=acos(test*train'/(norm(test,2)*norm(train,2)));     % cos distance
                dist(j,1)=(-1) * abs(Test_data(i,:)*Train_data(j,:)') / (norm(Test_data(i,:),2)*norm(Train_data(j,:),2)); % for simple
            otherwise
                dist(j,1)=norm(V,2); % Default distance
        end
    end
    [dummy, ind0] = min(dist);

    % compute the class labels of the 1 nearest samples
    ind = find(Train_label(ind0) == U); %find the label of the nearest neighbors 
    
    % determine the class of the data sample
    Result(i) = U(ind);
end
correctnumbers = length(find(Result==Test_label));
rate = correctnumbers/test_num;


