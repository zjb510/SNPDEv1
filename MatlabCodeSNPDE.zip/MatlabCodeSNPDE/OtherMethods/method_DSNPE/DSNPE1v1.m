function [eigVecs, eigVals] = DSNPE1v1(train_sample,train_label, max_dim, gama)

% class_num:
% train_sample:
% train_label:
% test_sample:
% test_label:
% pro_dim:
% p:
class_num = length(unique(train_label));

S = computeS_DSNPE1(train_sample, train_label);

S = S + S' - S'*S;
S = eye(size(S)) - S;
S_W = train_sample*S*train_sample';
clear S;
S_B = train_sample*train_sample';   

m_samples = mean(train_sample, 2); % Total mean in eigenspace

k = size(train_sample, 1);
Sw = zeros(k, k); % Initialization os Within Scatter Matrix
Sb = zeros(k, k); % Initialization of Between Scatter Matrix

for i = 1 : class_num
    ind = find(train_label == i);
    m = mean(train_sample(:, ind), 2);    
    
    for j0 = 1 : length(ind)
        j = ind(j0);
        Sw = Sw + (train_sample(:,j)-m)*(train_sample(:,j)-m)';     % Within Scatter Matrix
    end
    
    Sb = Sb + length(ind)*(m-m_samples) * (m-m_samples)'; % Between Scatter Matrix
end
clear m m_samples;

S_W = S_W - gama*(Sb-Sw);
clear Sb Sw;

[eigVecs, eigVals] = eig(S_B, S_W);
clear S_B S_W;

eigVals = diag(eigVals);
[eigVals, index] = sort(eigVals, 'descend'); 
eigVecs = eigVecs(:, index);
eigVecs = eigVecs(:, 1:min(size(eigVecs,2), max_dim));
