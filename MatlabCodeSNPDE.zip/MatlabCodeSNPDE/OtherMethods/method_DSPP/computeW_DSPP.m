
function [W] = computeW_DSPP(train_sample, train_label)

class_num = max(unique(train_label));
train_tol = size(train_sample,2);
W = sparse(train_tol,train_tol);

for i = 1 : class_num
    indi = find(train_label==i);
    ki = length(indi);
    Xi = train_sample(:,indi);    
    si = zeros(ki,ki);
    for j = 1 : ki
        X = [Xi(:,1:(j-1)) Xi(:,(j+1):ki)];
        x = Xi(:,j);
        
        sij = SolveHomotopy_CBM_std(X, x, 'lambda', 0.01); % min_x  \lambda ||x||_1 + 1/2*||y-Ax||_2^2
        %sij = SolvePDIPA_CBM_std(X, x, 'lambda', 0.01);   % min_x ||x||_1  s.t.  Ax = b
        %sij = SolveL1LS_CBM(X, x, 'lambda', 0.01);        % minimize ||A*x-y||^2 + lambda*sum|x_i|,
        %sij = SolveL1LS(X, x, 'lambda', 0.01);           % minimize ||A*x-y||^2 + lambda*sum|x_i|
        
%       sij = sij/norm(sij, 1);
        v = sum(sij);
        if ~isnan(v) && abs(v) > 1e-5
            sij = sij / v;
        else
            sij = zeros(length(sij), 1);
        end
        
        for k = 1 : ki
            if k < j
                si(j,k)=sij(k);
            elseif k > j
                si(j,k)=sij(k-1);
            end
        end
    end
    W(indi,indi) = si;    
end




