
function [W, B, d] = computeWBd_DSPP_H(train_sample, train_label)

W = computeW_DSPP(train_sample, train_label);

class_num = max(unique(train_label));
train_tol = size(train_sample,2);
nImgPerClass = train_tol/class_num;

B = W;
d = zeros(train_tol,1);

k = 1;
for i = 1 : class_num
    s2 = (i-1)*nImgPerClass;
    t1 = i*nImgPerClass+1;
    X = [train_sample(:,1:s2) train_sample(:,t1:train_tol)];
    
    indi = find(train_label==i);
    for j = indi
        x = train_sample(:,j); 
        sij = SolveHomotopy_CBM_std(X, x,'lambda', 0.01);
        v = sum(sij);
        if ~isnan(v) && abs(v) > 1e-5
            sij = sij / v;
        else
            sij = zeros(length(sij), 1);
        end
	B(1:s2,k) = sij(1:s2);
	B(t1:train_tol,k) = sij(s2+1: train_tol-nImgPerClass);
        k = k + 1;
    end
end

for i = 1 : train_tol
    Wi = W(i,:);
    Wi(Wi==0)=inf;    
    [xx,indi] = min(Wi);
    d(i) = norm(train_sample(:,i)-train_sample(:,indi));    
end