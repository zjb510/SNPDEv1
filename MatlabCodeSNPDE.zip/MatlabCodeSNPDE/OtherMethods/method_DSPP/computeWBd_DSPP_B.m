
function [W, B, d] = computeWBd_DSPP_B(train_sample, train_label)

W = computeW_DSPP(train_sample, train_label);

train_tol = size(train_sample,2);
B = W;
d = zeros(train_tol,1);

for i = 1 : train_tol
    Wi = W(i,:);
    Wi(Wi==0) = inf;    
    [xx, indi] = min(Wi);
    d(i) = norm(train_sample(:,i) - train_sample(:,indi));    
    for j = 1 : train_tol
        if train_label(i) ~= train_label(j)
            dij = norm(train_sample(:,i) - train_sample(:,j));
            if dij < d(i)
                B(i,j) = 1;
            end
        end
    end    
end