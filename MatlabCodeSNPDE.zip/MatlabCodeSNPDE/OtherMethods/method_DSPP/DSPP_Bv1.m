function [eigVecs, eigVals] = DSPP_Bv1(train_sample, train_label, max_dim, p)

% class_num:
% train_sample:
% train_label:
% test_sample:
% test_label:
% pro_dim:
% p:


[W, B, d] = computeWBd_DSPP_B(train_sample, train_label);

class_num = length(unique(train_label));
train_tol = size(train_sample, 2);

Lw = diag(sum(W,2)) - W;
Lb = diag(sum(B,2)) - B;
clear W B;

S_W = train_sample*Lw*train_sample';
S_B = train_sample*Lb*train_sample';   
clear Lb Lw;

k = size(train_sample, 1);
Sw = zeros(k,k);
clear k;

mt = zeros(size(train_sample,1),class_num);
for i = 1 : class_num
    mt(:,i) = mean(train_sample(:,find(train_label == i)),2);
end
for i = 1 : train_tol
    for j = 1 : train_tol
        if train_label(j) ~= train_label(i)
            if norm(train_sample(:,j)-train_sample(:,i)) < d(i)
                Sw = Sw + (train_sample(:,j)-mt(:,train_label(j)))*(train_sample(:,j)-mt(:,train_label(j)))';
            end
        end
    end
end
clear mt d;

S_W = S_W + p*Sw;
clear Sw;

[eigVecs, eigVals] = eig(S_B, S_W);
clear S_B S_W;

eigVals = diag(eigVals);
[eigVals, index] = sort(eigVals, 'descend'); 
eigVecs = eigVecs(:, index);
eigVecs = eigVecs(:, 1:min(size(eigVecs,2),max_dim));