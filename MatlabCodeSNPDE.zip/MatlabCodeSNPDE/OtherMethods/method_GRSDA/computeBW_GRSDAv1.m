
function [B, W] = computeBW_GRSDAv1(fea, gnd)


class_num = max(unique(gnd));
[N, nSmp] = size(fea);
%fea = fea./repmat(max(fea), N, 1);
% fea = fea/255;
B = zeros(nSmp,nSmp);
W = zeros(nSmp,nSmp);

for i = 1 : class_num
    
    indiB = find(gnd==i);
    kiB = length(indiB);
    XiB = fea(:,indiB);
    siB = zeros(kiB,kiB);
    
    indiW = find(gnd~=i);
    XW = fea(:,indiW);
    siW = zeros(kiB,class_num*kiB);
    
    k = indiB(1)-1;
    for j = 1:kiB
        XB = [XiB(:,1:(j-1)) XiB(:,(j+1):kiB)];
        x = XiB(:,j);
        
        sijB = SolveHomotopy_CBM_std(XB, x, 'lambda', 0.01); % min_x  \lambda ||x||_1 + 1/2*||y-Ax||_2^2
        %sijB = sijB / sum(sijB);        
        if isnan(sijB)
            sijB = zeros(length(sijB), 1);
        end
        
        siB(j,1:j-1)=sijB(1:j-1)';
        siB(j,j+1:end)=sijB(j:end)';
        
        sijW = SolveHomotopy_CBM_std(XW, x, 'lambda', 0.01); % min_x  \lambda ||x||_1 + 1/2*||y-Ax||_2^2
        %sijW = sijW / sum(sijW);
        if isnan(sijW)
            sijW = zeros(length(sijW),1);
        end
        
        siW(j,1:k)=sijW(1:k)';
        siW(j,k+kiB+1:end)=sijW(k+1:end)';
    end
    W(indiB,:) = siW;
    B(indiB,indiB) = siB; 
end