function [eigVecs, eigVals] = GRSDAv1(fea, gnd, max_dim)

% class_num:
% fea:
% gnd:
% test_sample:
% test_label:
% pro_dim:
% p:

[B, W] = computeBW_GRSDAv1(fea, gnd);

D = diag(sum(W,2)+sum(W,1)');
W = (W + W')/2;

Lw =  D - W;
clear W;
SW = fea*Lw*fea';
clear Lw;

D = diag(sum(B,2)+sum(B,1)');
B = (B + B')/2;

Lb =  D - B;
clear D B;
SB = fea*Lb*fea';
clear Lb;

[eigVecs, eigVals] = eig(SB, SW);
clear SW SB;

eigVals = diag(eigVals);
[eigVals, index] = sort(eigVals,'descend'); 
eigVecs = eigVecs(:, index);
eigVecs = eigVecs(:, 1:min(size(eigVecs,2),max_dim));
