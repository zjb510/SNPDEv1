function [eigVecs, eigVals] = SMMSDv1(train_sample, train_label, max_dim)

%%
% SMMSD: Sparse Multiple Maximum Scatter Difference
%
%   Sparse multiple maximum scatter difference for dimensionality reduction
%
%   [eigVecs, eigVals] = SMMSDv1(train_sample, train_label, max_dim);
%   Input:
%      train_sample - Data matrix. Each column vector of fea is a data point.
%      train_label  - Data label vector.
%      max_dim      - maximum number of dimensionality of subspace
%
%   Output:
%      eigVecs    - Each column is an embedding, for a new
%                   data point (colume vector) x, 
%                   y = eig_vec'* x will be the embedding
%                   result of x.
%      eigVals    - The sorted eigvalue of eig_vec. 
% 
%
%    Examples:
%
%       fea = rand(100,50);
%       gnd = [ones(1,10) 2*ones(1,10) 3*ones(1,10) 4*ones(1,10) 5*ones(1,10)];
%       gama = 0.1;
%       max_dim = 200;
%       [eigVecs, eigVals] = SMMSDv1(train_sample, train_label, max_dim);
%       Y = eigVecs'*fea;       
%
%
%   Feb. 2018 
%   
%
%   Written by Jianbo Zhang (zjb510@126.com  zhangjianbo@neuq.edu.cn)
%
%%
kappa = 0.01;% 0.05
[B, W] = computeBW_SMMSDv1(train_sample, train_label, kappa);

S1 = B - W;
S2 = train_sample*train_sample';
clear B W train_sample;

[eigVecs, eigVals] = eig(S1, S2);
clear S1 S2;

eigVals = diag(eigVals);
[eigVals, index] = sort(eigVals, 'descend'); 
eigVecs = eigVecs(:, index);
eigVecs = eigVecs(:, 1:min(size(eigVecs,2), max_dim));
