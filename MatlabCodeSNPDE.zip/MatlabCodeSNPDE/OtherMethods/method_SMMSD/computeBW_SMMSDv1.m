
function [B, W] = computeBW_SMMSDv1(train_sample, train_label, kappa)

% train_sample: each column corresponds to one sample

%
%
%
train_label_ID = unique(train_label);
class_num = length(train_label_ID);

W = zeros(size(train_sample,1));

for i = 1 : class_num
    indi = find(train_label==train_label_ID(i));
    ki = length(indi);
    Xi = train_sample(:,indi);
    si = zeros(ki,ki);
    for j = 1 : ki
        X = [Xi(:,1:(j-1)) Xi(:,(j+1):ki)];
        x = Xi(:,j);
        
        sij = (X'*X + kappa*eye(size(X,2)))\X'*x;
        sij = sij./norm(sij,1);
        
        si(j, 1:j-1) = sij(1:j-1);
        si(j, j+1:ki) = sij(j:ki-1);
    end
    
    W = W + Xi*(eye(ki)-si)*(eye(ki)-si)'*Xi';
end

%
%
%
M = zeros(size(train_sample,1),class_num);
for i = 1 : class_num
    indi = find(train_label == train_label_ID(i));
    Xi = train_sample(:,indi);
    M(:,i) = mean(Xi,2);
end
clear Xi;

si = zeros(class_num, class_num);
for i = 1 : class_num
    X = [M(:,1:(i-1)) M(:,(i+1):class_num)];
    x = M(:,i);
    sij = (X'*X + kappa*eye(size(X,2)))\X'*x;
    sij = sij./norm(sij,1);
    
    si(i, 1:i-1) = sij(1:i-1);
    si(i, i+1:class_num) = sij(i:class_num-1);
end

B = M*(eye(class_num)-si)*(eye(class_num)-si)'*M';
