function [W] = computeW_SPP1(fea, gnd)

class_num = max(unique(gnd));
[N, nSmp] = size(fea);
W = sparse(nSmp,nSmp);

for i = 1 : class_num
    indi = find(gnd==i);
    ki = length(indi);
    Xi = fea(:,indi);    
    si = zeros(ki,ki);
    for j = 1:ki
        X = [Xi(:,1:(j-1)) Xi(:,(j+1):ki)];
        x = Xi(:,j);
        
        %sij = LeastR(X, x, 0.01); % ���ܵ��� SparCoef
        %sij = SolvePDIPA_CBM_std(X, x, 'lambda', 0.01);   % min_x ||x||_1  s.t.  Ax = b
        sij = SolveHomotopy_CBM_std(X, x, 'lambda', 0.01); % min_x  \lambda ||x||_1 + 1/2*||y-Ax||_2^2
        %sij = SolveL1LS_CBM(X, x, 'lambda', 0.01);        % minimize ||A*x-y||^2 + lambda*sum|x_i|,
        %sij = SolveL1LS(X, x, 'lambda', 0.01);           % minimize ||A*x-y||^2 + lambda*sum|x_i|
        
        v = sum(sij);
        if ~isnan(v) && abs(v) > 1e-5
            sij = sij / v;
        else
            sij = zeros(length(sij), 1);
        end
        
        for k = 1:ki
            if k < j
                si(j,k)=sij(k);
            elseif k > j
                si(j,k)=sij(k-1);
            end
        end
    end
    W(indi,indi) = si;    
end

%%% �����Ƿ�ȡ��
% for i = 1 : nSmp
%     SS = sum(W(:,i));
%     if SS > 0 
%         W(:,i) = W(:,i)/SS;
%     end
% end