function [W] = computeW_SPP2(fea, gnd)

class_num = max(unique(gnd));
[D, nSmp] = size(fea);
W = sparse(nSmp,nSmp);

for i = 1 : class_num
    indi = find(gnd==i);
    ki = length(indi);
    X = [zeros(D, ki-1) eye(D); ones(1,ki-1) zeros(1,D)];
    x = ones(D+1,1);
    Xi = fea(:,indi);    
    si = zeros(ki,ki);
    for j = 1:ki
        X0 = [Xi(:,1:(j-1)) Xi(:,(j+1):ki)];
        X(1:D, 1:ki-1) = X0;
        x0 = Xi(:,j);
        x(1:D) = x0;

        %w0 = X\x;%�ȼ���inv(A)*y
        %sij = l1eq_pd(w0, X, [], x, 1e-3);%%%%%%%%%---!!!!!!!!!!---%%%%%%%%%

        %sij = SolvePDIPA_CBM_std(X, x, 'lambda', 0.01);   % min_x ||x||_1  s.t.  Ax = b
        sij = SolveHomotopy_CBM_std(X, x, 'lambda', 0.01); % min_x  \lambda ||x||_1 + 1/2*||y-Ax||_2^2
        %sij = SolveL1LS_CBM(X, x, 'lambda', 0.01);        % minimize ||A*x-y||^2 + lambda*sum|x_i|,
        %sij = SolveL1LS(X, x, 'lambda', 0.01);           % minimize ||A*x-y||^2 + lambda*sum|x_i|
        
        %sij = sij(1:ki-1);
        %sij(find(sij<0)) = 0;
        %sij = sij / sum(sij);
        
        v = sum(sij);
        if ~isnan(v) && abs(v) > 1e-5
            sij = sij / v;
        else
            sij = zeros(length(sij), 1);
        end
        
        for k = 1:ki
            if k < j
                si(j,k)=sij(k);
            elseif k > j
                si(j,k)=sij(k-1);
            end
        end
    end
    W(indi,indi) = si;    
end
% for i = 1 : nSmp
%     SS = sum(W(:,i));
%     if SS > 0 
%         W(:,i) = W(:,i)/SS;
%     end
% end