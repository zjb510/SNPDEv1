function [ww_SPP, D_ss] = SPP1v1(fea, gnd, max_dim)

% class_num:
% fea:
% gnd:
% test_sample:
% test_label:
% pro_dim:
% p:

W = computeW_SPP1(fea, gnd);

delmat = fea * (W + W' - W * W') * fea';
ss = fea * fea';

[V_ss, D_ss] = eig(delmat, ss);
D_ss = diag(D_ss);
[D_ss, dd_site] = sort(D_ss, 'descend');
ww_SPP = [];

for ii = 1 : min(max_dim, size(V_ss, 2))
    ww_SPP = [ww_SPP, V_ss(:, dd_site(ii)) / norm(V_ss(:, dd_site(ii)))];
end