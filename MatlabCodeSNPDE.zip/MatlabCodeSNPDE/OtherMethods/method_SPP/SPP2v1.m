function [ww_SPP, D_ss] = SPP2v1(fea,gnd,max_dim)

% class_num:
% fea:
% gnd:
% test_sample:
% test_label:
% pro_dim:
% p:

W = computeW_SPP2(fea, gnd);

delmat = fea * (W + W' - W * W') * fea';
ss = fea * fea';

[V_ss, D_ss] = eig(delmat, ss);
D_ss = diag(D_ss);
[D_ss, dd_site] = sort(D_ss, 'descend');
k = min(max_dim, size(V_ss, 2));
V_ss = V_ss(:, dd_site);
ww_SPP = V_ss(:, 1:min(size(V_ss,2),max_dim));
 
for ii = 1 : k
    ww_SPP(:,ii) = ww_SPP(:,ii)/ norm(ww_SPP(:,ii));
end