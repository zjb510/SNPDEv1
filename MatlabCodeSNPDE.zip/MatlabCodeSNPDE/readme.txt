
  Open Matlab Window, and run "mainSNPDE.m" directly