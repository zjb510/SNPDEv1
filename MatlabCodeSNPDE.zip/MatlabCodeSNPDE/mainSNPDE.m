clear
%clc
%close all
addpath(genpath(pwd));

%mainSNPDE_Yale_32X32
mainSNPDE_EYB_32X32
%mainSNPDE_AR_44X32
mainSNPDE_PIE_32X32
