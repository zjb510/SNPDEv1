% tol_num = 24;
% class_num = 68;
% database = 'PIE';
% nTrain = 10;

% tol_num = 14;
% class_num = 100;
% database = 'AR14s';
% nTrain = 8;

% tol_num = 64;
% class_num = 31;
% database = 'EYB';
% nTrain = 11;

tol_num = 11;
class_num = 15;
database = 'Yale';
nTrain = 7;

% tol_num = 10;
% class_num = 14;
% database = 'ORL';
% nTrain = 4;

repeattime = 50;

for i = 1 : repeattime
    gnd_train = [];
    gnd_test = [];
    for j = 1 : class_num
        ind = randperm(tol_num)';
        ind = ind + (j-1)*tol_num;
        gnd_train = [gnd_train; ind(1:nTrain)];
        gnd_test = [gnd_test; ind(nTrain+1:tol_num)];
    end
    filename = strcat(pwd,'\DATA\n-trains\',database,'\',num2str(nTrain),'-train\',num2str(i),'.mat');
    save(filename, 'gnd_train', 'gnd_test');
end